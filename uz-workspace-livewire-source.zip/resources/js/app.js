import axios from 'axios';

window.axios = axios;
window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

document.addEventListener('livewire:init', () => {
    Livewire.on('workspace:copied', ({ text }) => {
        if (navigator.clipboard) navigator.clipboard.writeText(text);
    });
});
