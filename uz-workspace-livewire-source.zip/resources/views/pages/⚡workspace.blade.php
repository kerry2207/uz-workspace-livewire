<?php

use Illuminate\Support\Str;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Url;
use Livewire\Component;
use Livewire\WithFileUploads;

new class extends Component {
    use WithFileUploads;

    #[Url(as: 'view')]
    public string $view = 'home';

    public bool $sidebarCollapsed = false;
    public bool $workspaceMenuOpen = false;
    public bool $searchOpen = false;
    public bool $notificationsOpen = false;
    public bool $commentsOpen = false;
    public bool $favorite = false;
    public ?string $modal = null;
    public ?string $toast = null;
    public string $workspaceScope = 'uz';
    public string $taskView = 'board';
    public string $taskFilter = 'all';
    public string $search = '';
    public string $pageTitle = '';
    public string $pageIcon = '✨';
    public string $newTaskTitle = '';
    public string $newTaskStatus = 'Заплановано';
    public string $newTaskPriority = 'Середній';
    public string $newTaskDue = '';
    public string $newWorkspaceName = '';
    public string $newStatusName = '';
    public string $newStatusTone = 'blue';
    public string $newColumnName = '';
    public string $newComment = '';
    public $pageImage;

    public array $workspaces = [
        ['id' => 'uz', 'name' => 'УЗ · Workspace', 'description' => 'Директорський workspace', 'initials' => 'УЗ'],
        ['id' => 'personal', 'name' => 'Каріна · Workspace', 'description' => 'Приватні сторінки', 'initials' => 'КБ'],
    ];

    public array $statuses = [
        ['name' => 'Заплановано', 'tone' => 'gray'],
        ['name' => 'В роботі', 'tone' => 'blue'],
        ['name' => 'На перевірці', 'tone' => 'orange'],
        ['name' => 'Готово', 'tone' => 'green'],
    ];

    public array $columns = [
        ['id' => 'planned', 'name' => 'Заплановано', 'tone' => 'gray'],
        ['id' => 'active', 'name' => 'В роботі', 'tone' => 'blue'],
        ['id' => 'review', 'name' => 'На перевірці', 'tone' => 'orange'],
        ['id' => 'done', 'name' => 'Готово', 'tone' => 'green'],
    ];

    public array $tasks = [
        ['id' => 'task-1', 'title' => 'Оновити порожні стани', 'project' => 'UZ Workspace', 'status' => 'Заплановано', 'column' => 'planned', 'priority' => 'Середній', 'due' => '05 сер', 'owner' => 'КБ', 'people' => ['КБ', 'ОМ'], 'tags' => ['дизайн', 'ux']],
        ['id' => 'task-2', 'title' => 'Головна сторінка простору', 'project' => 'UZ Workspace', 'status' => 'В роботі', 'column' => 'active', 'priority' => 'Високий', 'due' => 'Сьогодні', 'owner' => 'КБ', 'people' => ['КБ', 'АС'], 'tags' => ['workspace', 'frontend']],
        ['id' => 'task-3', 'title' => 'Перевірити сценарій повернення', 'project' => 'Booking Web', 'status' => 'В роботі', 'column' => 'active', 'priority' => 'Високий', 'due' => '02 сер', 'owner' => 'ОМ', 'people' => ['ОМ', 'МК'], 'tags' => ['booking', 'дослідження']],
        ['id' => 'task-4', 'title' => 'Компоненти мобільного квитка', 'project' => 'МТКД Mobile', 'status' => 'На перевірці', 'column' => 'review', 'priority' => 'Середній', 'due' => '04 сер', 'owner' => 'АС', 'people' => ['АС'], 'tags' => ['mobile', 'ui-kit']],
        ['id' => 'task-5', 'title' => 'Підключити design tokens', 'project' => 'UZ Workspace', 'status' => 'Готово', 'column' => 'done', 'priority' => 'Низький', 'due' => '30 лип', 'owner' => 'КБ', 'people' => ['КБ'], 'tags' => ['design-system']],
    ];

    public array $blocks = [
        ['id' => 'block-1', 'type' => 'text', 'content' => 'Почніть писати або натисніть «+», щоб додати блок.', 'checked' => false],
        ['id' => 'block-2', 'type' => 'checklist', 'content' => 'Підготувати перший варіант', 'checked' => true],
        ['id' => 'block-3', 'type' => 'checklist', 'content' => 'Передати сторінку на ревʼю', 'checked' => false],
    ];

    public array $comments = [
        ['id' => 'comment-1', 'author' => 'Олена Михайлюк', 'initials' => 'ОМ', 'text' => 'Додала уточнення до нотаток зустрічі.', 'time' => '5 хв', 'resolved' => false],
        ['id' => 'comment-2', 'author' => 'Андрій Стеценко', 'initials' => 'АС', 'text' => 'Оновив посилання на робочі матеріали.', 'time' => '42 хв', 'resolved' => false],
    ];

    public array $inbox = [
        ['id' => 'notice-1', 'title' => 'Олена згадала вас у коментарі', 'meta' => 'Booking / Робочі матеріали · 5 хв', 'tone' => 'blue', 'read' => false],
        ['id' => 'notice-2', 'title' => 'Запит на доступ до сторінки', 'meta' => 'МТКД / План релізу · 18 хв', 'tone' => 'orange', 'read' => false],
        ['id' => 'notice-3', 'title' => 'Андрій завершив задачу', 'meta' => 'UZ Workspace · 1 год', 'tone' => 'green', 'read' => true],
    ];

    public array $pages = [
        ['id' => 'page-1', 'title' => 'ТЗ авторизації', 'space' => 'Booking', 'icon' => '📄', 'updated' => 'Сьогодні'],
        ['id' => 'page-2', 'title' => 'FAQ', 'space' => 'МТКД', 'icon' => '💬', 'updated' => 'Сьогодні'],
        ['id' => 'page-3', 'title' => 'Нотатки Product Sync', 'space' => 'Мій простір', 'icon' => '📝', 'updated' => 'Учора'],
    ];

    public function navigate(string $view): void
    {
        $allowed = ['home', 'tasks', 'calendar', 'inbox', 'pages', 'shared', 'recent', 'files', 'teamspace', 'projects', 'people', 'editor'];
        if (! in_array($view, $allowed, true)) return;

        $this->view = $view;
        $this->closeOverlays();
    }

    public function closeOverlays(): void
    {
        $this->workspaceMenuOpen = false;
        $this->searchOpen = false;
        $this->notificationsOpen = false;
        $this->modal = null;
    }

    public function selectWorkspace(string $id): void
    {
        if (collect($this->workspaces)->contains('id', $id)) {
            $this->workspaceScope = $id;
            $this->workspaceMenuOpen = false;
            $this->toast = 'Workspace змінено';
        }
    }

    public function createWorkspace(): void
    {
        $this->validate(['newWorkspaceName' => ['required', 'string', 'min:2', 'max:60']]);
        $name = trim($this->newWorkspaceName);
        $this->workspaces[] = [
            'id' => (string) Str::uuid(),
            'name' => $name.' · Workspace',
            'description' => 'Новий workspace',
            'initials' => mb_strtoupper(mb_substr($name, 0, 2)),
        ];
        $this->newWorkspaceName = '';
        $this->modal = null;
        $this->toast = 'Workspace створено';
    }

    public function setTaskView(string $view): void
    {
        if (in_array($view, ['board', 'table', 'list', 'calendar'], true)) $this->taskView = $view;
    }

    public function addTask(): void
    {
        $this->validate(['newTaskTitle' => ['required', 'string', 'min:2', 'max:160']]);
        $column = collect($this->columns)->firstWhere('name', $this->newTaskStatus)['id'] ?? 'planned';
        $this->tasks[] = [
            'id' => (string) Str::uuid(),
            'title' => trim($this->newTaskTitle),
            'project' => 'UZ Workspace',
            'status' => $this->newTaskStatus,
            'column' => $column,
            'priority' => $this->newTaskPriority,
            'due' => $this->newTaskDue ?: 'Без терміну',
            'owner' => 'КБ',
            'people' => ['КБ'],
            'tags' => ['нова'],
        ];
        $this->newTaskTitle = '';
        $this->newTaskDue = '';
        $this->modal = null;
        $this->toast = 'Задачу створено';
    }

    public function updateTaskStatus(string $id, string $status): void
    {
        $index = collect($this->tasks)->search(fn ($task) => $task['id'] === $id);
        if ($index === false) return;

        $this->tasks[$index]['status'] = $status;
        $this->tasks[$index]['column'] = collect($this->columns)->firstWhere('name', $status)['id'] ?? $this->tasks[$index]['column'];
        $this->toast = 'Статус оновлено';
    }

    public function updateTaskPriority(string $id, string $priority): void
    {
        $index = collect($this->tasks)->search(fn ($task) => $task['id'] === $id);
        if ($index !== false && in_array($priority, ['Низький', 'Середній', 'Високий'], true)) {
            $this->tasks[$index]['priority'] = $priority;
        }
    }

    public function sortTask(string $id, int $position, string $columnId): void
    {
        $index = collect($this->tasks)->search(fn ($task) => $task['id'] === $id);
        if ($index === false) return;

        $task = $this->tasks[$index];
        array_splice($this->tasks, $index, 1);
        $column = collect($this->columns)->firstWhere('id', $columnId);
        $task['column'] = $columnId;
        $task['status'] = $column['name'] ?? $task['status'];
        $targets = array_keys(array_filter($this->tasks, fn ($item) => $item['column'] === $columnId));
        $insertAt = $targets[$position] ?? count($this->tasks);
        array_splice($this->tasks, $insertAt, 0, [$task]);
    }

    public function createStatus(): void
    {
        $this->validate(['newStatusName' => ['required', 'string', 'min:2', 'max:40']]);
        if (! collect($this->statuses)->contains('name', trim($this->newStatusName))) {
            $this->statuses[] = ['name' => trim($this->newStatusName), 'tone' => $this->newStatusTone];
        }
        $this->newStatusName = '';
        $this->modal = null;
        $this->toast = 'Статус додано';
    }

    public function createColumn(): void
    {
        $this->validate(['newColumnName' => ['required', 'string', 'min:2', 'max:40']]);
        $this->columns[] = ['id' => (string) Str::uuid(), 'name' => trim($this->newColumnName), 'tone' => 'blue'];
        $this->newColumnName = '';
        $this->modal = null;
        $this->toast = 'Колонку створено';
    }

    public function addBlock(string $type = 'text', ?int $after = null): void
    {
        $allowed = ['text', 'heading', 'bullets', 'checklist', 'quote', 'callout', 'divider', 'table', 'board', 'image', 'file', 'link', 'page'];
        if (! in_array($type, $allowed, true)) $type = 'text';
        $block = ['id' => (string) Str::uuid(), 'type' => $type, 'content' => '', 'checked' => false];
        $position = $after === null ? count($this->blocks) : min($after + 1, count($this->blocks));
        array_splice($this->blocks, $position, 0, [$block]);
    }

    public function sortBlock(string $id, int $position): void
    {
        $index = collect($this->blocks)->search(fn ($block) => $block['id'] === $id);
        if ($index === false) return;
        $block = $this->blocks[$index];
        array_splice($this->blocks, $index, 1);
        array_splice($this->blocks, $position, 0, [$block]);
    }

    public function duplicateBlock(string $id): void
    {
        $index = collect($this->blocks)->search(fn ($block) => $block['id'] === $id);
        if ($index === false) return;
        $copy = $this->blocks[$index];
        $copy['id'] = (string) Str::uuid();
        array_splice($this->blocks, $index + 1, 0, [$copy]);
    }

    public function deleteBlock(string $id): void
    {
        $this->blocks = array_values(array_filter($this->blocks, fn ($block) => $block['id'] !== $id));
    }

    public function savePageImage(): void
    {
        $this->validate(['pageImage' => ['required', 'image', 'max:4096']]);
        $this->pageImage->store(path: 'page-images', options: 'public');
        $this->toast = 'Зображення додано';
    }

    public function addComment(): void
    {
        $this->validate(['newComment' => ['required', 'string', 'min:2', 'max:800']]);
        $this->comments[] = ['id' => (string) Str::uuid(), 'author' => 'Каріна Барановська', 'initials' => 'КБ', 'text' => trim($this->newComment), 'time' => 'Щойно', 'resolved' => false];
        $this->newComment = '';
        $this->toast = 'Коментар додано';
    }

    public function resolveComment(string $id): void
    {
        $index = collect($this->comments)->search(fn ($comment) => $comment['id'] === $id);
        if ($index !== false) $this->comments[$index]['resolved'] = true;
    }

    public function markInboxRead(string $id): void
    {
        $index = collect($this->inbox)->search(fn ($notice) => $notice['id'] === $id);
        if ($index !== false) $this->inbox[$index]['read'] = true;
    }

    public function createPage(): void
    {
        $title = trim($this->pageTitle) ?: 'Без назви';
        $this->pages[] = ['id' => (string) Str::uuid(), 'title' => $title, 'space' => 'Мій простір', 'icon' => $this->pageIcon, 'updated' => 'Щойно'];
        $this->toast = 'Сторінку збережено';
    }

    public function copyPageLink(): void
    {
        $this->dispatch('workspace:copied', text: url('/?view=editor'));
        $this->toast = 'Посилання скопійовано';
    }

    public function clearToast(): void
    {
        $this->toast = null;
    }

    #[Computed]
    public function currentWorkspace(): array
    {
        return collect($this->workspaces)->firstWhere('id', $this->workspaceScope) ?? $this->workspaces[0];
    }

    #[Computed]
    public function visibleTasks(): array
    {
        return array_values(array_filter($this->tasks, function ($task) {
            if ($this->taskFilter === 'today') return $task['due'] === 'Сьогодні';
            if ($this->taskFilter === 'urgent') return $task['priority'] === 'Високий';
            if ($this->taskFilter === 'review') return $task['status'] === 'На перевірці';
            return true;
        }));
    }

    #[Computed]
    public function searchResults(): array
    {
        $query = mb_strtolower(trim($this->search));
        if ($query === '') return array_slice($this->pages, 0, 3);
        return array_values(array_filter($this->pages, fn ($page) => str_contains(mb_strtolower($page['title'].' '.$page['space']), $query)));
    }
};
?>

<div class="uz-shell {{ $sidebarCollapsed ? 'sidebar-is-collapsed' : '' }}">
    <aside class="sidebar" aria-label="Основна навігація">
        <div class="sidebar-head">
            <button class="workspace-brand" type="button" wire:click="$toggle('workspaceMenuOpen')" aria-expanded="{{ $workspaceMenuOpen ? 'true' : 'false' }}">
                <span class="brand-mark">{{ $this->currentWorkspace['initials'] }}</span>
                <span class="brand-copy"><strong>{{ $this->currentWorkspace['name'] }}</strong><small>{{ $this->currentWorkspace['description'] }}</small></span>
                <x-phosphor-caret-down class="nav-icon brand-caret" />
            </button>
            <button class="icon-button sidebar-toggle" type="button" wire:click="$toggle('sidebarCollapsed')" aria-label="{{ $sidebarCollapsed ? 'Розгорнути сайдбар' : 'Згорнути сайдбар' }}">
                @if ($sidebarCollapsed)<x-phosphor-caret-right class="nav-icon" />@else<x-phosphor-caret-left class="nav-icon" />@endif
            </button>
        </div>

        @if ($workspaceMenuOpen)
            <div class="workspace-menu" wire:transition>
                <p>Ваші workspace</p>
                @foreach ($workspaces as $workspace)
                    <button type="button" wire:key="workspace-{{ $workspace['id'] }}" wire:click="selectWorkspace('{{ $workspace['id'] }}')" class="{{ $workspaceScope === $workspace['id'] ? 'active' : '' }}">
                        <span>{{ $workspace['initials'] }}</span><span><strong>{{ $workspace['name'] }}</strong><small>{{ $workspace['description'] }}</small></span>
                        @if ($workspaceScope === $workspace['id'])<x-phosphor-check class="mini-icon" />@endif
                    </button>
                @endforeach
                <hr>
                <button type="button" wire:click="$set('modal','workspace')"><span><x-phosphor-plus /></span><span><strong>Новий workspace</strong><small>Створити окремий простір</small></span></button>
                <button type="button" wire:click="$set('modal','settings')"><span><x-phosphor-gear /></span><span><strong>Налаштування</strong><small>Профіль і доступи</small></span></button>
            </div>
        @endif

        <nav>
            <p class="nav-label">Workspace</p>
            <button type="button" wire:click="navigate('home')" class="{{ $view === 'home' ? 'active' : '' }}"><x-phosphor-house class="nav-icon" /><span>Головна</span></button>
            <button type="button" wire:click="navigate('tasks')" class="{{ $view === 'tasks' ? 'active' : '' }}"><x-phosphor-check-square class="nav-icon" /><span>Загальні задачі</span></button>
            <button type="button" wire:click="navigate('projects')" class="{{ $view === 'projects' ? 'active' : '' }}"><x-phosphor-briefcase class="nav-icon" /><span>Проєкти</span></button>
            <button type="button" wire:click="navigate('inbox')" class="{{ $view === 'inbox' ? 'active' : '' }}"><x-phosphor-tray class="nav-icon" /><span>Вхідні</span><em>{{ collect($inbox)->where('read', false)->count() }}</em></button>
            <button type="button" wire:click="navigate('calendar')" class="{{ $view === 'calendar' ? 'active' : '' }}"><x-phosphor-calendar-dots class="nav-icon" /><span>Календар</span></button>
            <button type="button" wire:click="$set('searchOpen',true)"><x-phosphor-magnifying-glass class="nav-icon" /><span>Пошук</span><kbd>⌘ K</kbd></button>

            <p class="nav-label">Сторінки</p>
            <button type="button" wire:click="navigate('pages')" class="{{ $view === 'pages' ? 'active' : '' }}"><x-phosphor-file-text class="nav-icon" /><span>Мої сторінки</span></button>
            <button type="button" wire:click="navigate('shared')" class="{{ $view === 'shared' ? 'active' : '' }}"><x-phosphor-users-three class="nav-icon" /><span>Спільні зі мною</span></button>
            <button type="button" wire:click="navigate('recent')" class="{{ $view === 'recent' ? 'active' : '' }}"><x-phosphor-clock-counter-clockwise class="nav-icon" /><span>Останні</span></button>
            <button type="button" wire:click="navigate('files')" class="{{ $view === 'files' ? 'active' : '' }}"><x-phosphor-folder-open class="nav-icon" /><span>Файли</span></button>
            <button type="button" wire:click="navigate('editor')" class="new-page-link {{ $view === 'editor' ? 'active' : '' }}"><x-phosphor-plus class="nav-icon" /><span>Нова сторінка</span></button>

            <p class="nav-label">Спільні простори</p>
            <button type="button" wire:click="navigate('teamspace')" class="{{ $view === 'teamspace' ? 'active' : '' }}"><span class="space-avatar blue">Ц</span><span>Цифрові продукти</span></button>
            <button type="button" wire:click="navigate('teamspace')"><span class="space-avatar orange">П</span><span>Пасажирські сервіси</span></button>
            <button type="button" wire:click="navigate('teamspace')"><span class="space-avatar navy">М</span><span>Мобільні застосунки</span></button>
            <button type="button" wire:click="$set('modal','workspace')"><x-phosphor-plus-circle class="nav-icon" /><span>Створити простір</span></button>
        </nav>
    </aside>

    <main>
        <header class="topbar">
            <div class="breadcrumbs"><span>{{ $this->currentWorkspace['name'] }}</span><i>/</i><strong>{{ match($view) { 'home' => 'Головна', 'tasks' => 'Загальні задачі', 'editor' => 'Нова сторінка', 'teamspace' => 'Цифрові продукти', 'calendar' => 'Календар', 'inbox' => 'Вхідні', 'files' => 'Файли', 'projects' => 'Проєкти', default => 'Сторінки' } }}</strong></div>
            <div class="top-actions">
                <button class="icon-button" type="button" wire:click="$set('searchOpen',true)" aria-label="Пошук"><x-phosphor-magnifying-glass /></button>
                <button class="icon-button notice-button" type="button" wire:click="$toggle('notificationsOpen')" aria-label="Сповіщення"><x-phosphor-bell /><span></span></button>
                <button class="primary-button" type="button" wire:click="$set('modal','create')"><x-phosphor-plus />Створити</button>
            </div>
            @if ($notificationsOpen)
                <div class="notifications-popover" wire:transition>
                    <header><strong>Сповіщення</strong><button type="button" wire:click="$set('notificationsOpen',false)"><x-phosphor-x /></button></header>
                    @foreach (array_slice($inbox, 0, 3) as $notice)
                        <button type="button" wire:click="markInboxRead('{{ $notice['id'] }}')"><span class="notice-dot {{ $notice['tone'] }}"></span><span><strong>{{ $notice['title'] }}</strong><small>{{ $notice['meta'] }}</small></span></button>
                    @endforeach
                </div>
            @endif
        </header>

        <div class="page-body">
            @if ($view === 'home')
                <section class="hero-panel">
                    <div><span class="eyebrow">ПЕРСОНАЛЬНА ГОЛОВНА</span><h1>Добрий день, Каріно 👋</h1><p>Огляд подій з усіх просторів, до яких ви маєте доступ.</p></div>
                    <div class="hero-orbit"><span>УЗ</span></div>
                </section>

                <section class="stats-grid">
                    <button type="button" wire:click="navigate('tasks')" class="stat-card blue"><x-phosphor-checks /><span><strong>{{ collect($tasks)->where('due','Сьогодні')->count() }}</strong><small>задачі сьогодні</small><em>2 термінові</em></span></button>
                    <button type="button" wire:click="navigate('calendar')" class="stat-card orange"><x-phosphor-calendar-blank /><span><strong>1</strong><small>зустріч</small><em>о 15:30</em></span></button>
                    <button type="button" wire:click="navigate('inbox')" class="stat-card green"><x-phosphor-chat-circle-dots /><span><strong>2</strong><small>нові згадки</small><em>за сьогодні</em></span></button>
                    <button type="button" wire:click="navigate('shared')" class="stat-card purple"><x-phosphor-user-circle-plus /><span><strong>1</strong><small>запит на доступ</small><em>очікує</em></span></button>
                </section>

                <section class="dashboard-grid">
                    <article class="dashboard-card span-2">
                        <header><div><span class="section-kicker">ВАШ РОЗКЛАД</span><h2>Сьогодні</h2></div><button type="button" wire:click="navigate('calendar')">Відкрити календар<x-phosphor-arrow-right /></button></header>
                        <div class="timeline-row"><time>10:00</time><span class="timeline-line blue"></span><div><strong>Підготувати макети для review</strong><small>Цифрові продукти / Задачі команди</small></div><span class="status-pill blue">В роботі</span></div>
                        <div class="timeline-row"><time>15:30</time><span class="timeline-line orange"></span><div><strong>Product Sync</strong><small>Booking / Зустрічі · 6 учасників</small></div><span class="status-pill orange">Зустріч</span></div>
                    </article>
                    <article class="dashboard-card">
                        <header><div><span class="section-kicker">ФОКУС</span><h2>Мої задачі</h2></div><button type="button" wire:click="navigate('tasks')">Всі<x-phosphor-arrow-right /></button></header>
                        <div class="compact-list">
                            @foreach (array_slice($tasks, 0, 3) as $task)
                                <button type="button" wire:click="navigate('tasks')"><span class="check-dot {{ $task['status'] === 'Готово' ? 'done' : '' }}"></span><span><strong>{{ $task['title'] }}</strong><small>{{ $task['project'] }} · {{ $task['due'] }}</small></span></button>
                            @endforeach
                        </div>
                    </article>
                    <article class="dashboard-card">
                        <header><div><span class="section-kicker">ОСТАННЄ</span><h2>Спільні зі мною</h2></div><button type="button" wire:click="navigate('shared')">Всі<x-phosphor-arrow-right /></button></header>
                        <div class="compact-list people-list"><button type="button"><span class="avatar blue">ОМ</span><span><strong>Чернетка ТЗ</strong><small>Олена Михайлюк · Перегляд</small></span></button><button type="button"><span class="avatar orange">АС</span><span><strong>План дослідження</strong><small>Андрій Стеценко · Редагування</small></span></button></div>
                    </article>
                    <article class="dashboard-card span-2">
                        <header><div><span class="section-kicker">ШВИДКИЙ ДОСТУП</span><h2>Корпоративні сервіси</h2></div></header>
                        <div class="service-grid"><a href="https://booking.uz.gov.ua/" target="_blank"><span class="service-icon orange">🎫</span><strong>Booking</strong><small>Квитки та поїздки</small></a><a href="#"><span class="service-icon blue">🚆</span><strong>МТКД</strong><small>Мобільний застосунок</small></a><a href="#"><span class="service-icon green">📊</span><strong>MIV</strong><small>Аналітика</small></a><a href="#"><span class="service-icon purple">📅</span><strong>Календар</strong><small>Події команди</small></a></div>
                    </article>
                </section>
            @elseif ($view === 'tasks')
                <section class="page-heading"><div><span class="eyebrow">КОМАНДНА БАЗА</span><h1>Загальні задачі</h1><p>Статуси, пріоритети, відповідальні та терміни видно одразу.</p></div><button class="primary-button" type="button" wire:click="$set('modal','task')"><x-phosphor-plus />Нова задача</button></section>
                <section class="database-toolbar">
                    <div class="view-switcher"><button type="button" wire:click="setTaskView('board')" class="{{ $taskView === 'board' ? 'active' : '' }}"><x-phosphor-kanban />Дошка</button><button type="button" wire:click="setTaskView('table')" class="{{ $taskView === 'table' ? 'active' : '' }}"><x-phosphor-table />Таблиця</button><button type="button" wire:click="setTaskView('list')" class="{{ $taskView === 'list' ? 'active' : '' }}"><x-phosphor-list-bullets />Список</button><button type="button" wire:click="setTaskView('calendar')" class="{{ $taskView === 'calendar' ? 'active' : '' }}"><x-phosphor-calendar-dots />Календар</button></div>
                    <div class="toolbar-actions"><select wire:model.live="taskFilter"><option value="all">Всі задачі</option><option value="today">Сьогодні</option><option value="urgent">Високий пріоритет</option><option value="review">На перевірці</option></select><button type="button"><x-phosphor-funnel />Фільтри</button><button type="button"><x-phosphor-arrows-down-up />Сортування</button></div>
                </section>

                @if ($taskView === 'board')
                    <section class="kanban-board">
                        @foreach ($columns as $column)
                            <article class="kanban-column" wire:key="column-{{ $column['id'] }}">
                                <header><span class="column-dot {{ $column['tone'] }}"></span><strong>{{ $column['name'] }}</strong><em>{{ collect($this->visibleTasks)->where('column',$column['id'])->count() }}</em><button type="button" wire:click="$set('modal','task')"><x-phosphor-plus /></button></header>
                                <div class="task-stack" wire:sort="sortTask" wire:sort:group="tasks" wire:sort:group-id="{{ $column['id'] }}">
                                    @foreach (collect($this->visibleTasks)->where('column',$column['id']) as $task)
                                        <article class="task-card" wire:key="{{ $task['id'] }}" wire:sort:item="{{ $task['id'] }}">
                                            <div class="task-card-top"><span wire:sort:handle><x-phosphor-dots-six-vertical /></span><button type="button"><x-phosphor-dots-three /></button></div>
                                            <strong>{{ $task['title'] }}</strong><small>{{ $task['project'] }}</small>
                                            <div class="task-properties">
                                                <div x-data="{open:false}" class="property-menu"><button type="button" @click="open=!open" class="priority-pill {{ strtolower(match($task['priority']){'Високий'=>'high','Середній'=>'medium',default=>'low'}) }}"><x-phosphor-flag />{{ $task['priority'] }}<x-phosphor-caret-down /></button><div x-show="open" @click.outside="open=false" x-transition class="property-dropdown"><button wire:click="updateTaskPriority('{{ $task['id'] }}','Низький')" @click="open=false"><span class="priority-dot low"></span>Низький</button><button wire:click="updateTaskPriority('{{ $task['id'] }}','Середній')" @click="open=false"><span class="priority-dot medium"></span>Середній</button><button wire:click="updateTaskPriority('{{ $task['id'] }}','Високий')" @click="open=false"><span class="priority-dot high"></span>Високий</button></div></div>
                                                <span class="due-pill"><x-phosphor-calendar-blank />{{ $task['due'] }}</span>
                                            </div>
                                            <div class="task-tags">@foreach ($task['tags'] as $tag)<span>#{{ $tag }}</span>@endforeach</div>
                                            <footer><div class="avatar-stack">@foreach ($task['people'] as $person)<span>{{ $person }}</span>@endforeach</div><span><x-phosphor-chat-circle />{{ $task['id'] === 'task-2' ? '3' : '1' }}</span></footer>
                                        </article>
                                    @endforeach
                                </div>
                            </article>
                        @endforeach
                        <button class="add-column" type="button" wire:click="$set('modal','column')"><x-phosphor-plus />Нова колонка</button>
                    </section>
                @elseif ($taskView === 'table')
                    <section class="task-table">
                        <div class="task-table-row header"><span>Назва</span><span>Статус</span><span>Пріоритет</span><span>Люди</span><span>Термін</span></div>
                        @foreach ($this->visibleTasks as $task)
                            <div class="task-table-row" wire:key="table-{{ $task['id'] }}"><span><strong>{{ $task['title'] }}</strong><small>{{ $task['project'] }}</small></span><span><select wire:change="updateTaskStatus('{{ $task['id'] }}',$event.target.value)" class="status-select {{ collect($statuses)->firstWhere('name',$task['status'])['tone'] ?? 'gray' }}">@foreach($statuses as $status)<option value="{{ $status['name'] }}" @selected($task['status'] === $status['name'])>{{ $status['name'] }}</option>@endforeach</select></span><span><span class="priority-pill {{ strtolower(match($task['priority']){'Високий'=>'high','Середній'=>'medium',default=>'low'}) }}"><x-phosphor-flag />{{ $task['priority'] }}</span></span><span><div class="avatar-stack">@foreach ($task['people'] as $person)<i>{{ $person }}</i>@endforeach</div></span><span>{{ $task['due'] }}</span></div>
                        @endforeach
                        <button class="table-add-row" type="button" wire:click="$set('modal','task')"><x-phosphor-plus />Нова задача</button>
                    </section>
                @elseif ($taskView === 'calendar')
                    <section class="month-calendar"><header><button type="button"><x-phosphor-caret-left /></button><h2>Серпень 2026</h2><button type="button"><x-phosphor-caret-right /></button></header><div class="week-labels">@foreach(['Пн','Вт','Ср','Чт','Пт','Сб','Нд'] as $day)<span>{{ $day }}</span>@endforeach</div><div class="month-grid">@for($day=1;$day<=35;$day)<article class="{{ $day > 31 ? 'outside' : '' }}"><span>{{ $day <= 31 ? $day : $day-31 }}</span>@foreach(array_slice(array_values(array_filter($tasks, fn($task)=>$task['due']==sprintf('%02d сер',$day))),0,2) as $task)<button type="button" class="calendar-task {{ collect($statuses)->firstWhere('name',$task['status'])['tone'] ?? 'gray' }}">{{ $task['title'] }}</button>@endforeach</article>@endfor</div></section>
                @else
                    <section class="task-list-view">@foreach($this->visibleTasks as $task)<article><span class="check-dot {{ $task['status'] === 'Готово' ? 'done' : '' }}"></span><div><strong>{{ $task['title'] }}</strong><small>{{ $task['project'] }}</small></div><span class="status-pill {{ collect($statuses)->firstWhere('name',$task['status'])['tone'] ?? 'gray' }}">{{ $task['status'] }}</span><span class="priority-pill {{ strtolower(match($task['priority']){'Високий'=>'high','Середній'=>'medium',default=>'low'}) }}">{{ $task['priority'] }}</span><time>{{ $task['due'] }}</time></article>@endforeach</section>
                @endif
            @elseif ($view === 'editor')
                <section class="editor-page">
                    <header class="editor-actions"><button type="button" wire:click="$toggle('favorite')" class="{{ $favorite ? 'active' : '' }}"><x-phosphor-star />{{ $favorite ? 'В обраному' : 'В обране' }}</button><button type="button" wire:click="$toggle('commentsOpen')"><x-phosphor-chat-circle />Коментарі</button><button type="button" wire:click="copyPageLink"><x-phosphor-share-network />Поділитися</button><button type="button"><x-phosphor-dots-three /></button></header>
                    <div class="page-cover-actions"><label><x-phosphor-image />Додати обкладинку<input type="file" wire:model="pageImage" accept="image/*" hidden></label>@if($pageImage)<button type="button" wire:click="savePageImage"><x-phosphor-upload-simple />Зберегти зображення</button>@endif</div>
                    @if($pageImage)<img class="page-cover-preview" src="{{ $pageImage->temporaryUrl() }}" alt="Попередній перегляд обкладинки">@endif
                    <div class="page-title-row"><button type="button" class="page-emoji">{{ $pageIcon }}</button><input type="text" wire:model.live.blur="pageTitle" placeholder="Без назви" aria-label="Назва сторінки"></div>
                    <div class="editor-blocks" wire:sort="sortBlock">
                        @foreach ($blocks as $index => $block)
                            <article class="editor-block block-{{ $block['type'] }}" wire:key="{{ $block['id'] }}" wire:sort:item="{{ $block['id'] }}" x-data="{ menu:false, add:false }">
                                <div class="block-controls"><button type="button" @click="add=!add" aria-label="Додати блок"><x-phosphor-plus /></button><button type="button" @click="menu=!menu" wire:sort:handle aria-label="Перетягнути блок або відкрити меню"><x-phosphor-dots-six-vertical /></button></div>
                                <div x-show="add" @click.outside="add=false" x-transition class="block-insert-menu"><strong>Додати блок</strong><button wire:click="addBlock('text',{{ $index }})" @click="add=false"><x-phosphor-text-t />Текст</button><button wire:click="addBlock('heading',{{ $index }})" @click="add=false"><x-phosphor-text-h-one />Заголовок</button><button wire:click="addBlock('checklist',{{ $index }})" @click="add=false"><x-phosphor-check-square />Чекліст</button><button wire:click="addBlock('table',{{ $index }})" @click="add=false"><x-phosphor-table />Таблиця</button><button wire:click="addBlock('image',{{ $index }})" @click="add=false"><x-phosphor-image />Зображення</button></div>
                                <div x-show="menu" @click.outside="menu=false" x-transition class="block-menu" wire:sort:ignore><strong>Дії з блоком</strong><button type="button"><x-phosphor-arrows-left-right />Перетворити</button><button type="button"><x-phosphor-paint-brush />Колір і фон</button><button type="button" wire:click="duplicateBlock('{{ $block['id'] }}')" @click="menu=false"><x-phosphor-copy />Дублювати</button><button type="button" wire:click="deleteBlock('{{ $block['id'] }}')" @click="menu=false" class="danger"><x-phosphor-trash />Видалити</button></div>

                                @if ($block['type'] === 'heading')
                                    <input class="block-heading" type="text" wire:model.live.blur="blocks.{{ $index }}.content" placeholder="Новий заголовок">
                                @elseif ($block['type'] === 'checklist')
                                    <label class="checklist-block"><input type="checkbox" wire:model.live="blocks.{{ $index }}.checked"><span></span><input type="text" wire:model.live.blur="blocks.{{ $index }}.content" placeholder="Нова задача"></label>
                                @elseif ($block['type'] === 'bullets')
                                    <label class="bullet-block"><span>•</span><input type="text" wire:model.live.blur="blocks.{{ $index }}.content" placeholder="Елемент списку"></label>
                                @elseif ($block['type'] === 'quote')
                                    <textarea class="quote-block" wire:model.live.blur="blocks.{{ $index }}.content" placeholder="Цитата"></textarea>
                                @elseif ($block['type'] === 'callout')
                                    <div class="callout-block"><span>💡</span><textarea wire:model.live.blur="blocks.{{ $index }}.content" placeholder="Важлива інформація"></textarea></div>
                                @elseif ($block['type'] === 'divider')
                                    <hr class="divider-block">
                                @elseif ($block['type'] === 'table')
                                    <div class="inline-table"><div><strong>Назва</strong><strong>Статус</strong><strong>Власник</strong></div><div><input placeholder="Новий запис"><span class="status-pill gray">Заплановано</span><span class="avatar blue">КБ</span></div><button type="button"><x-phosphor-plus />Новий рядок</button><button type="button"><x-phosphor-plus />Нова колонка</button></div>
                                @elseif ($block['type'] === 'board')
                                    <div class="inline-board"><article><strong><i class="column-dot gray"></i>Заплановано</strong><button type="button">Нова картка</button></article><article><strong><i class="column-dot blue"></i>В роботі</strong><button type="button">Нова картка</button></article><button type="button"><x-phosphor-plus />Нова колонка</button></div>
                                @elseif ($block['type'] === 'image')
                                    <label class="media-placeholder"><x-phosphor-image /><strong>Додати зображення</strong><small>PNG, JPG або WebP до 4 МБ</small><input type="file" wire:model="pageImage" accept="image/*" hidden></label>
                                @elseif ($block['type'] === 'file')
                                    <label class="media-placeholder"><x-phosphor-paperclip /><strong>Прикріпити файл</strong><small>Документи, таблиці або макети</small><input type="file" wire:model="pageImage" hidden></label>
                                @elseif ($block['type'] === 'link')
                                    <label class="link-block"><x-phosphor-link /><input type="url" wire:model.live.blur="blocks.{{ $index }}.content" placeholder="Вставте посилання"></label>
                                @elseif ($block['type'] === 'page')
                                    <label class="page-link-block"><span>📄</span><input type="text" wire:model.live.blur="blocks.{{ $index }}.content" placeholder="Назва вкладеної сторінки"></label>
                                @else
                                    <textarea class="text-block" wire:model.live.blur="blocks.{{ $index }}.content" placeholder="Введіть текст або натисніть / для команд"></textarea>
                                @endif
                            </article>
                        @endforeach
                    </div>
                    <div x-data="{open:false}" class="add-block-wrap"><button class="add-block-button" type="button" @click="open=!open"><x-phosphor-plus />Додати блок</button><div x-show="open" @click.outside="open=false" x-transition class="slash-menu"><header><x-phosphor-magnifying-glass /><input placeholder="Знайти блок..."></header><p>ОСНОВНІ БЛОКИ</p><button wire:click="addBlock('text')" @click="open=false"><x-phosphor-text-t /><span><strong>Текст</strong><small>Звичайний текстовий блок</small></span></button><button wire:click="addBlock('heading')" @click="open=false"><x-phosphor-text-h-one /><span><strong>Заголовок</strong><small>Великий заголовок секції</small></span></button><button wire:click="addBlock('checklist')" @click="open=false"><x-phosphor-check-square /><span><strong>Чекліст</strong><small>Задача з відміткою</small></span></button><button wire:click="addBlock('table')" @click="open=false"><x-phosphor-table /><span><strong>Таблиця</strong><small>База даних у вигляді таблиці</small></span></button><button wire:click="addBlock('board')" @click="open=false"><x-phosphor-kanban /><span><strong>Дошка</strong><small>Kanban з колонками</small></span></button><button wire:click="addBlock('image')" @click="open=false"><x-phosphor-image /><span><strong>Зображення</strong><small>Завантажити або вставити</small></span></button></div></div>
                    <footer class="editor-footer"><span>Останнє редагування щойно</span><button class="primary-button" type="button" wire:click="createPage"><x-phosphor-floppy-disk />Зберегти сторінку</button></footer>
                </section>
            @elseif ($view === 'calendar')
                <section class="page-heading"><div><span class="eyebrow">ПОДІЇ З УСІХ ПРОСТОРІВ</span><h1>Календар</h1><p>Зустрічі, терміни задач і командні події в одному місці.</p></div><button class="primary-button" type="button" wire:click="$set('modal','meeting')"><x-phosphor-plus />Нова зустріч</button></section>
                <section class="month-calendar large"><header><button type="button"><x-phosphor-caret-left /></button><h2>Серпень 2026</h2><button type="button"><x-phosphor-caret-right /></button></header><div class="week-labels">@foreach(['Пн','Вт','Ср','Чт','Пт','Сб','Нд'] as $day)<span>{{ $day }}</span>@endforeach</div><div class="month-grid">@for($day=1;$day<=35;$day)<article class="{{ $day > 31 ? 'outside' : '' }}"><span>{{ $day <= 31 ? $day : $day-31 }}</span>@if($day===3)<button class="calendar-event blue">Design review · 11:00</button>@endif @if($day===5)<button class="calendar-event orange">Product Sync · 15:30</button>@endif @if($day===12)<button class="calendar-event green">Реліз МТКД</button>@endif</article>@endfor</div></section>
            @elseif ($view === 'inbox')
                <section class="page-heading"><div><span class="eyebrow">ВАШІ ОНОВЛЕННЯ</span><h1>Вхідні</h1><p>Згадки, запити на доступ і зміни в задачах.</p></div></section>
                <section class="inbox-list">@foreach($inbox as $notice)<button type="button" wire:click="markInboxRead('{{ $notice['id'] }}')" class="{{ $notice['read'] ? 'read' : '' }}"><span class="notice-dot {{ $notice['tone'] }}"></span><span><strong>{{ $notice['title'] }}</strong><small>{{ $notice['meta'] }}</small></span>@if(!$notice['read'])<em>Нове</em>@endif</button>@endforeach</section>
            @elseif (in_array($view, ['pages','shared','recent','files','projects']))
                <section class="page-heading"><div><span class="eyebrow">{{ $view === 'files' ? 'МАТЕРІАЛИ КОМАНДИ' : 'ВАШ КОНТЕНТ' }}</span><h1>{{ match($view){'pages'=>'Мої сторінки','shared'=>'Спільні зі мною','recent'=>'Останні','files'=>'Файли','projects'=>'Проєкти'} }}</h1><p>Знайдіть потрібний матеріал або створіть новий.</p></div><button class="primary-button" type="button" wire:click="navigate('editor')"><x-phosphor-plus />Нова сторінка</button></section>
                <section class="content-toolbar"><label><x-phosphor-magnifying-glass /><input wire:model.live.debounce.250ms="search" placeholder="Знайти сторінку або файл"></label><div><button type="button"><x-phosphor-funnel />Фільтри</button><button type="button"><x-phosphor-grid-four />Сітка</button></div></section>
                <section class="content-grid">@foreach($pages as $page)<button type="button" wire:click="navigate('editor')"><span>{{ $page['icon'] }}</span><strong>{{ $page['title'] }}</strong><small>{{ $page['space'] }}</small><em>Оновлено {{ mb_strtolower($page['updated']) }}</em></button>@endforeach<button type="button" class="new-content-card" wire:click="navigate('editor')"><x-phosphor-plus /><strong>Нова сторінка</strong><small>Почніть з порожньої</small></button></section>
            @else
                <section class="page-heading"><div><span class="eyebrow">СПІЛЬНИЙ ПРОСТІР</span><h1>Цифрові продукти</h1><p>Проєкти, рішення, дослідження та спільні матеріали команди.</p></div><button class="primary-button" type="button" wire:click="navigate('editor')"><x-phosphor-plus />Нова сторінка</button></section>
                <section class="teamspace-overview"><article><span class="space-logo">Ц</span><div><strong>Цифрові продукти</strong><small>6 учасників · Ви адміністратор</small></div><button type="button"><x-phosphor-dots-three /></button></article><div class="teamspace-stats"><span><strong>18</strong><small>сторінок</small></span><span><strong>24</strong><small>задачі</small></span><span><strong>6</strong><small>учасників</small></span><span><strong>87%</strong><small>здоровʼя</small></span></div></section>
                <section class="content-grid teamspace-pages">@foreach($pages as $page)<button type="button" wire:click="navigate('editor')"><span>{{ $page['icon'] }}</span><strong>{{ $page['title'] }}</strong><small>{{ $page['space'] }}</small><em>Оновлено {{ mb_strtolower($page['updated']) }}</em></button>@endforeach</section>
            @endif
        </div>
    </main>

    @if ($commentsOpen)
        <aside class="comments-panel" wire:transition>
            <header><div><span class="eyebrow">ОБГОВОРЕННЯ</span><h2>Коментарі</h2></div><button type="button" wire:click="$set('commentsOpen',false)"><x-phosphor-x /></button></header>
            <div class="comments-list">@foreach($comments as $comment)<article class="{{ $comment['resolved'] ? 'resolved' : '' }}"><span class="avatar blue">{{ $comment['initials'] }}</span><div><header><strong>{{ $comment['author'] }}</strong><time>{{ $comment['time'] }}</time></header><p>{{ $comment['text'] }}</p>@if(!$comment['resolved'])<button type="button" wire:click="resolveComment('{{ $comment['id'] }}')"><x-phosphor-check />Закрити</button>@else<small>Закрито</small>@endif</div></article>@endforeach</div>
            <form wire:submit="addComment" class="comment-composer"><textarea wire:model="newComment" placeholder="Напишіть коментар або @згадайте колегу"></textarea><button class="primary-button" type="submit"><x-phosphor-paper-plane-tilt />Надіслати</button></form>
        </aside>
    @endif

    @if ($searchOpen)
        <div class="modal-backdrop" wire:click.self="$set('searchOpen',false)" wire:transition>
            <section class="search-modal"><header><x-phosphor-magnifying-glass /><input autofocus wire:model.live.debounce.200ms="search" placeholder="Знайти сторінку, проєкт або людину"><kbd>ESC</kbd></header><p>РЕЗУЛЬТАТИ</p><div>@forelse($this->searchResults as $page)<button type="button" wire:click="navigate('editor')"><span>{{ $page['icon'] }}</span><span><strong>{{ $page['title'] }}</strong><small>{{ $page['space'] }}</small></span><x-phosphor-arrow-right /></button>@empty<div class="empty-search">Нічого не знайдено</div>@endforelse</div><footer><span><kbd>↵</kbd> відкрити</span><span><kbd>↑↓</kbd> навігація</span></footer></section>
        </div>
    @endif

    @if ($modal)
        <div class="modal-backdrop" wire:click.self="$set('modal',null)" wire:transition>
            <section class="modal-card">
                <header><div><span class="modal-icon"><x-phosphor-sparkle /></span><div><h2>{{ match($modal){'task'=>'Нова задача','workspace'=>'Новий workspace','status'=>'Новий статус','column'=>'Нова колонка','meeting'=>'Нова зустріч','settings'=>'Налаштування',default=>'Створити'} }}</h2><p>{{ match($modal){'task'=>'Вкажіть основні властивості задачі.','workspace'=>'Окремий простір для команди або проєкту.','column'=>'Колонка організує картки на дошці, але не створює статус.','meeting'=>'Подія зʼявиться у спільному календарі.','settings'=>'Профіль, доступи та сповіщення.',default=>'Оберіть, що потрібно додати.'} }}</p></div></div><button type="button" wire:click="$set('modal',null)"><x-phosphor-x /></button></header>
                @if ($modal === 'task')
                    <form wire:submit="addTask" class="modal-form"><label><span>Назва</span><input wire:model="newTaskTitle" placeholder="Наприклад, підготувати макети"></label><div class="form-grid"><label><span>Статус</span><select wire:model="newTaskStatus">@foreach($statuses as $status)<option>{{ $status['name'] }}</option>@endforeach</select></label><label><span>Пріоритет</span><select wire:model="newTaskPriority"><option>Низький</option><option>Середній</option><option>Високий</option></select></label></div><label><span>Термін</span><input type="date" wire:model="newTaskDue"></label><label><span>Учасники</span><div class="people-field"><span class="avatar blue">КБ</span><strong>Каріна Барановська</strong><button type="button"><x-phosphor-plus /></button></div></label><footer><button type="button" wire:click="$set('modal',null)">Скасувати</button><button class="primary-button" type="submit">Створити задачу</button></footer></form>
                @elseif ($modal === 'workspace')
                    <form wire:submit="createWorkspace" class="modal-form"><label><span>Назва workspace</span><input wire:model="newWorkspaceName" placeholder="Наприклад, Booking Web"></label><label><span>Доступ</span><select><option>Приватний</option><option>Для всієї команди</option><option>За запрошенням</option></select></label><footer><button type="button" wire:click="$set('modal',null)">Скасувати</button><button class="primary-button" type="submit">Створити workspace</button></footer></form>
                @elseif ($modal === 'column')
                    <form wire:submit="createColumn" class="modal-form"><label><span>Назва колонки</span><input wire:model="newColumnName" placeholder="Наприклад, Заблоковано"></label><div class="logic-note"><x-phosphor-info /><span><strong>Колонка — це структура дошки</strong><small>Статус задачі створюється окремо у властивостях бази.</small></span></div><footer><button type="button" wire:click="$set('modal',null)">Скасувати</button><button class="primary-button" type="submit">Додати колонку</button></footer></form>
                @elseif ($modal === 'create')
                    <div class="create-grid"><button type="button" wire:click="navigate('editor')"><x-phosphor-file-plus /><span><strong>Сторінка</strong><small>Порожня сторінка з блоками</small></span></button><button type="button" wire:click="$set('modal','task')"><x-phosphor-check-square /><span><strong>Задача</strong><small>Додати до загальних задач</small></span></button><button type="button" wire:click="$set('modal','meeting')"><x-phosphor-calendar-plus /><span><strong>Зустріч</strong><small>Додати до календаря</small></span></button><button type="button" wire:click="$set('modal','workspace')"><x-phosphor-users-three /><span><strong>Спільний простір</strong><small>Створити workspace</small></span></button></div>
                @else
                    <div class="settings-placeholder"><x-phosphor-gear /><strong>Налаштування готові до підключення</strong><p>Розробник може звʼязати цей екран з профілем, ролями та політиками Laravel.</p></div>
                @endif
            </section>
        </div>
    @endif

    @if ($toast)
        <div class="toast" x-data x-init="setTimeout(() => $wire.clearToast(), 2600)" wire:transition><x-phosphor-check-circle />{{ $toast }}</div>
    @endif
</div>
