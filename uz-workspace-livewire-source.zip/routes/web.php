<?php

use Illuminate\Support\Facades\Route;

Route::livewire('/', 'pages::workspace')->name('workspace');
