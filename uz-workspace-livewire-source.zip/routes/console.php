<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('uz:ready', function (): void {
    $this->info('UZ Workspace Livewire frontend is ready.');
})->purpose('Verify the application console is available');
